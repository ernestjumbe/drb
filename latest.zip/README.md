.. {% comment %}

===============
Dj Layout
===============

     django-admin.py startproject --template=https://github.com/ernestjumbe/django-bootstrap-template/zipball/master --extension=py,rst,gitignore,example project_name

.. note:: The text following this comment block will become the README.rst of the new project.

-----

.. {% endcomment %}
