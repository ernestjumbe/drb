from detrundebord.settings.base import *
