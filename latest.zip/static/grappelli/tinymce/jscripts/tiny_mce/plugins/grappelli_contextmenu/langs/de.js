tinyMCE.addI18n("de.grappelli_contextmenu",{
grappelli_contextmenu_insertpbefore_desc:"Absatz VOR aktuellem ELEMENT einfügen",
grappelli_contextmenu_insertpafter_desc:"Absatz NACH aktuellen ELEMENT einfügen",
grappelli_contextmenu_insertpbeforeroot_desc:"Absatz VOR aktuellem HAUPTELEMENT einfügen",
grappelli_contextmenu_insertpafterroot_desc:"Absatz NACH aktuellen HAUPTELEMENT einfügen",
grappelli_contextmenu_delete_desc:"Aktuelles ELEMENT löschen",
grappelli_contextmenu_deleteroot_desc:"Aktuelles HAUPTELEMENT löschen",
grappelli_contextmenu_moveup_desc:"Aktuelles ELEMENT NACH OBEN verschieben",
grappelli_contextmenu_moveuproot_desc:"Aktuelles HAUPTELEMENT NACH OBEN verschieben",

P_grappelli_contextmenu_insertpbefore_desc:"Absatz VOR Absatz einfügen",
P_grappelli_contextmenu_insertpafter_desc:"Absatz NACH Absatz einfügen",
P_grappelli_contextmenu_insertpbeforeroot_desc:"Absatz VOR Template einfügen",
P_grappelli_contextmenu_insertpafterroot_desc:"Absatz NACH Template einfügen",
P_grappelli_contextmenu_delete_desc:"Absatz löschen",
P_grappelli_contextmenu_deleteroot_desc:"Template löschen",
P_grappelli_contextmenu_moveup_desc:"Absatz NACH OBEN verschieben",
P_grappelli_contextmenu_moveuproot_desc:"Template NACH OBEN verschieben",

});
